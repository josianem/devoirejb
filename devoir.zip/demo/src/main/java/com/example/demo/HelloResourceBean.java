package com.example.demo;
import javax.ejb.Stateless;

@Stateless
public class HelloResourceBean implements HelloResource{
    @Override
    public String hello() {
        return "Hello this is a stateless session bean";
    }
}
