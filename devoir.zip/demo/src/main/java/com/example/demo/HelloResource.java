package com.example.demo;
import javax.ejb.Remote;

@Remote
public interface HelloResource {
    public String hello();
}
